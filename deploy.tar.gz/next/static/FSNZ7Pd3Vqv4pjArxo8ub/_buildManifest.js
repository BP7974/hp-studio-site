self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/98b0fe724a750977.js"
  ],
  "/_error": [
    "static/chunks/8c8177d52d6f46c5.js"
  ],
  "/auth": [
    "static/chunks/65575bd7acaff6a6.js"
  ],
  "/dashboard": [
    "static/chunks/9a556e6ca4dc2df2.js"
  ],
  "/explore": [
    "static/chunks/e34a9a93dee61bea.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/api/auth/forgot",
    "/api/auth/login",
    "/api/auth/logout",
    "/api/auth/me",
    "/api/auth/register",
    "/api/auth/reset",
    "/api/auth/send-email-code",
    "/api/auth/send-phone-code",
    "/api/auth/send-reset-email-code",
    "/api/auth/send-reset-phone-code",
    "/api/files/download/[id]",
    "/api/files/list",
    "/api/files/mine",
    "/api/files/upload",
    "/auth",
    "/dashboard",
    "/explore"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()