__turbopack_load_page_chunks__("/", [
  "static/chunks/d01f5806e49cd2f6.js",
  "static/chunks/e4a7808872c6aaf7.js",
  "static/chunks/5205ada799cb7f0e.js",
  "static/chunks/turbopack-c480d74e8b9b43d9.js"
])
