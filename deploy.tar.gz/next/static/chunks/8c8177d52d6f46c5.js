__turbopack_load_page_chunks__("/_error", [
  "static/chunks/79e2095ba55d04e6.js",
  "static/chunks/e4a7808872c6aaf7.js",
  "static/chunks/5205ada799cb7f0e.js",
  "static/chunks/turbopack-3ed15e47143c4c9b.js"
])
