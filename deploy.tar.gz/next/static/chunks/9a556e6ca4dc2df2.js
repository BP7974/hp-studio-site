__turbopack_load_page_chunks__("/dashboard", [
  "static/chunks/0509855952e7e80c.js",
  "static/chunks/e4a7808872c6aaf7.js",
  "static/chunks/5205ada799cb7f0e.js",
  "static/chunks/turbopack-90da3b351bd40814.js"
])
