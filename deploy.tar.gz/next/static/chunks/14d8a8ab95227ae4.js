__turbopack_load_page_chunks__("/_app", [
  "static/chunks/7c9581b7381a01b0.js",
  "static/chunks/e4a7808872c6aaf7.js",
  "static/chunks/5205ada799cb7f0e.js",
  "static/chunks/a2e7adcb50ed826e.css",
  "static/chunks/turbopack-fd898b96f3f3aa06.js"
])
