var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[externals]_fs_54ffce70._.js")
R.c("server/chunks/ssr/[root-of-the-server]__52939c23._.js")
R.c("server/chunks/ssr/[root-of-the-server]__56e741ad._.js")
R.m(7342)
module.exports=R.m(7342).exports
