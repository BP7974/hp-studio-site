var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__b00fd6f7._.js")
R.c("server/chunks/ssr/node_modules_next_5f45e247._.js")
R.c("server/chunks/ssr/[root-of-the-server]__68d47023._.js")
R.m(3590)
module.exports=R.m(3590).exports
