var R=require("../../../../chunks/[turbopack]_runtime.js")("server/pages/api/files/download/[id].js")
R.c("server/chunks/[root-of-the-server]__0acee1c2._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(8199)
module.exports=R.m(8199).exports
