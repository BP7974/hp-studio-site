var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/send-email-code.js")
R.c("server/chunks/[root-of-the-server]__3eff7f9d._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(2704)
module.exports=R.m(2704).exports
