var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/me.js")
R.c("server/chunks/[root-of-the-server]__3b58f3e0._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(5642)
module.exports=R.m(5642).exports
