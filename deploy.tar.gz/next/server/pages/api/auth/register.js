var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/register.js")
R.c("server/chunks/[root-of-the-server]__280d5dc2._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(1995)
module.exports=R.m(1995).exports
