var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/send-phone-code.js")
R.c("server/chunks/[root-of-the-server]__995a90e1._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(6233)
module.exports=R.m(6233).exports
