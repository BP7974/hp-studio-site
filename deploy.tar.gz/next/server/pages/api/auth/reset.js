var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/reset.js")
R.c("server/chunks/[root-of-the-server]__955a1466._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(6943)
module.exports=R.m(6943).exports
