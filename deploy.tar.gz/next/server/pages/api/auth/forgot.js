var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/forgot.js")
R.c("server/chunks/[root-of-the-server]__c8e0c1ca._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(2689)
module.exports=R.m(2689).exports
