var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/logout.js")
R.c("server/chunks/[root-of-the-server]__133ee067._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(9132)
module.exports=R.m(9132).exports
