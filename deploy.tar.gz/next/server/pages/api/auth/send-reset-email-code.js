var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/send-reset-email-code.js")
R.c("server/chunks/[root-of-the-server]__23ee66d4._.js")
R.c("server/chunks/[root-of-the-server]__118bec48._.js")
R.m(4381)
module.exports=R.m(4381).exports
