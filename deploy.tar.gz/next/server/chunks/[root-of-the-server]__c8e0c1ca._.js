module.exports=[406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},4747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},5372,(e,t,r)=>{t.exports=e.x("better-sqlite3",()=>require("better-sqlite3"))},2692,(e,t,r)=>{let a,s,o,i=e.r(4747),n=new(e.r(5372))(i.join(process.cwd(),"hpstudio.db"));n.pragma("journal_mode = WAL"),n.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),s=(a=n.prepare("PRAGMA table_info(users)").all()).find(e=>"email"===e.name),o=a.find(e=>"phone"===e.name),(s&&1===s.notnull||o&&1===o.notnull)&&n.transaction(()=>{n.exec("DROP TABLE IF EXISTS users__migration_backup"),n.exec(`
      CREATE TABLE users__migration_backup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `),n.exec(`
      INSERT INTO users__migration_backup (id, name, email, phone, password_hash, created_at)
      SELECT id, name, email, phone, password_hash, created_at FROM users;
    `),n.exec("DROP TABLE users;"),n.exec("ALTER TABLE users__migration_backup RENAME TO users;")})(),n.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),n.exec(`
  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),n.exec(`
  CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash
  ON password_resets(token_hash);
`),n.exec(`
  CREATE TABLE IF NOT EXISTS verification_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_type TEXT NOT NULL CHECK(target_type IN ('email', 'phone')),
    target_value TEXT NOT NULL,
    purpose TEXT NOT NULL DEFAULT 'register',
    code_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),n.exec(`
  CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup
  ON verification_codes(target_type, target_value, purpose, created_at DESC);
`),t.exports=n},4799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},7530,(e,t,r)=>{let a=e.r(4799),s=e.r(2692),o=Number(process.env.VERIFICATION_CODE_TTL_MINUTES||10),i=Number(process.env.VR_CODE_RESEND_SECONDS||process.env.VERIFICATION_RESEND_SECONDS||60),n=Number(process.env.VERIFICATION_CODE_LENGTH||6);function E(e,t){return t?"email"===e?String(t).trim().toLowerCase():String(t).trim():""}function T(e){return a.createHash("sha256").update(String(e)).digest("hex")}function p(e=n){let t="";for(let r=0;r<e;r+=1)t+=a.randomInt(0,10);return t}t.exports={createVerificationCode:function({targetType:e,targetValue:t,purpose:r="register",ttlMinutes:a=o,resendSeconds:n=i}){if(!["email","phone"].includes(e))throw Error("Unsupported target type");let u=E(e,t);if(!u)throw Error("Target value is required");!function(e,t,r,a){let o=s.prepare(`SELECT created_at FROM verification_codes
       WHERE target_type = ? AND target_value = ? AND purpose = ?
       AND used_at IS NULL
       ORDER BY created_at DESC
       LIMIT 1`).get(e,t,r);if(!o)return;let i=new Date(o.created_at).getTime(),n=(Date.now()-i)/1e3;if(n<a){let e=Math.ceil(a-n),t=Error(`请等待 ${e} 秒后再请求验证码`);throw t.code="RATE_LIMIT",t.retryAfter=e,t}}(e,u,r,n);let d=p(),l=new Date(Date.now()+60*a*1e3).toISOString(),c=T(d);return s.prepare(`INSERT INTO verification_codes (target_type, target_value, purpose, code_hash, expires_at)
     VALUES (?, ?, ?, ?, ?)`).run(e,u,r,c,l),{code:d,expiresAt:l}},verifyVerificationCode:function({targetType:e,targetValue:t,code:r,purpose:a="register",consume:o=!0}){if(!r)throw Error("验证码不能为空");let i=E(e,t),n=s.prepare(`SELECT id, code_hash, expires_at, used_at FROM verification_codes
       WHERE target_type = ? AND target_value = ? AND purpose = ?
       ORDER BY created_at DESC
       LIMIT 1`).get(e,i,a);if(!n)throw Error("请先获取验证码");if(n.used_at)throw Error("验证码已被使用，请重新获取");if(new Date(n.expires_at).getTime()<Date.now())throw Error("验证码已过期");if(T(r)!==n.code_hash)throw Error("验证码不正确");return o&&s.prepare("UPDATE verification_codes SET used_at = CURRENT_TIMESTAMP WHERE id = ?").run(n.id),!0},normalizeTarget:E,generateNumericCode:p}},8712,(e,t,r)=>{t.exports=e.x("nodemailer",()=>require("nodemailer"))},5066,(e,t,r)=>{let a=e.r(8712),s=null,o=null,i=Number(process.env.VERIFICATION_CODE_TTL_MINUTES||10);function n(){let{SMTP_HOST:e,SMTP_PORT:t,SMTP_SECURE:r,SMTP_USER:a,SMTP_PASS:s,SMTP_FROM:o}=process.env;if(!e||!a||!s||!o)return null;let i=Number(t||465),n="string"==typeof r?!["0","false","False","FALSE"].includes(r):465===i;return{host:e,port:i,secure:n,auth:{user:a,pass:s},from:o}}function E(){let e=n();if(!e)return s=null,o=null,null;let{from:t,...r}=e,i=JSON.stringify(r);return s&&i===o||(s=a.createTransport(r),o=i),s}t.exports={sendPasswordResetEmail:async function({to:e,resetUrl:t,token:r}){let a=E(),s=n();if(!a||!s)throw Error("SMTP is not configured");let o=`你正在请求重置 HP Studio 账号的密码。
重置链接：${t}
如果不是你本人操作，请忽略此邮件。`,i=`
    <p>你正在请求重置 HP Studio 账号的密码。</p>
    <p>点击以下链接即可完成重置（${process.env.PASSWORD_RESET_TTL_MINUTES||60} 分钟内有效）：</p>
    <p><a href="${t}">${t}</a></p>
    <p>如果不是你本人操作，请忽略此邮件。</p>
    <p style="color:#666;font-size:12px;">如果无法点击链接，可复制令牌：<code>${r}</code></p>
  `;await a.sendMail({from:s.from,to:e,subject:"HP Studio 密码重置",text:o,html:i})},sendVerificationEmail:async function({to:e,code:t,ttlMinutes:r=i,subject:a,text:s,html:o}){let T=E(),p=n();if(!T||!p)throw Error("SMTP is not configured");let u=s||`您的验证码是 ${t}，${r} 分钟内有效，请勿泄露给他人。`,d=o||`
    <p>您的 HP Studio 注册验证码：</p>
    <p style="font-size:24px;font-weight:bold;letter-spacing:2px;">${t}</p>
    <p>请在 ${r} 分钟内完成输入，该验证码仅供一次性使用。</p>
  `;await T.sendMail({from:p.from,to:e,subject:a||"HP Studio 注册验证码",text:u,html:d})},isSmtpConfigured:function(){return!!E()}}},3474,(e,t,r)=>{let a=e.r(4799),s=e.r(2692),{sendPasswordResetEmail:o,isSmtpConfigured:i}=e.r(5066),{verifyVerificationCode:n}=e.r(7530),E=parseInt(process.env.PASSWORD_RESET_TTL_MINUTES||"60",10);t.exports=async function(e,t){let r;if("POST"!==e.method)return t.setHeader("Allow",["POST"]),t.status(405).json({error:"Method Not Allowed"});let{email:T,phone:p,emailCode:u,phoneCode:d}=e.body||{};if(!T||!p||!u||!d)return t.status(400).json({error:"请填写邮箱、手机号及验证码"});let l=T.trim().toLowerCase(),c=p.trim();try{let T,p=s.prepare("SELECT id, email, name, phone FROM users WHERE LOWER(email) = ?").get(l);if(!p||p.phone!==c)return t.status(404).json({error:"账号信息不匹配"});try{n({targetType:"email",targetValue:l,code:u,purpose:"reset-email"}),n({targetType:"phone",targetValue:c,code:d,purpose:"reset-phone"})}catch(e){return t.status(400).json({error:e.message||"验证码校验失败"})}if(p){var _;let t=(_=r=a.randomBytes(32).toString("hex"),a.createHash("sha256").update(_).digest("hex")),n=new Date(Date.now()+60*E*1e3).toISOString();s.prepare("DELETE FROM password_resets WHERE user_id = ? AND (expires_at <= CURRENT_TIMESTAMP OR used_at IS NOT NULL)").run(p.id),s.prepare("INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, ?)").run(p.id,t,n),T=`${function(e){if(process.env.APP_BASE_URL)return process.env.APP_BASE_URL.replace(/\/$/,"");let t=e.headers["x-forwarded-proto"]||"http",r=e.headers["x-forwarded-host"]||e.headers.host;return`${t}://${r}`.replace(/\/$/,"")}(e)}/auth?token=${r}`,i()?o({to:p.email,resetUrl:T,token:r}).catch(e=>{console.error("Failed to send password reset email",e)}):console.log(`[Password reset] ${p.email} -> ${T}`)}return t.status(200).json({message:"如果账号存在，重置链接已经发送到邮箱。",resetToken:r,resetUrl:T})}catch(e){return console.error("Forgot password error",e),t.status(500).json({error:"请求失败"})}}},2689,e=>{"use strict";var t=e.i(6747),r=e.i(9245),a=e.i(4898),s=e.i(2950),o=e.i(3474),i=e.i(7031),n=e.i(1927),E=e.i(6432);let T=(0,s.hoist)(o,"default"),p=(0,s.hoist)(o,"config"),u=new a.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/auth/forgot",pathname:"/api/auth/forgot",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function d(e,r,a){u.isDev&&(0,E.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let s="/api/auth/forgot";s=s.replace(/\/index$/,"")||"/";let o=await u.prepare(e,r,{srcPage:s});if(!o){r.statusCode=400,r.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:T,params:p,prerenderManifest:d,routerServerContext:l}=o;try{let t=e.method||"GET",a=(0,i.getTracer)(),o=a.getActiveScopeSpan(),E=u.instrumentationOnRequestError.bind(u),c=async o=>u.render(e,r,{query:{...T,...p},params:p,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:d.preview,propagateError:!1,dev:u.isDev,page:"/api/auth/forgot",internalRevalidate:null==l?void 0:l.revalidate,onError:(...t)=>E(e,...t)}).finally(()=>{if(!o)return;o.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==n.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;o.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),o.updateName(e)}else o.updateName(`${t} ${s}`)});o?await c(o):await a.withPropagatedContext(e.headers,()=>a.trace(n.BaseServerSpan.handleRequest,{spanName:`${t} ${s}`,kind:i.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},c))}catch(e){if(u.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,p,"default",0,T,"handler",()=>d])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__c8e0c1ca._.js.map