module.exports=[406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},4747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},5372,(e,t,r)=>{t.exports=e.x("better-sqlite3",()=>require("better-sqlite3"))},2692,(e,t,r)=>{let a,i,s,E=e.r(4747),n=new(e.r(5372))(E.join(process.cwd(),"hpstudio.db"));n.pragma("journal_mode = WAL"),n.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),i=(a=n.prepare("PRAGMA table_info(users)").all()).find(e=>"email"===e.name),s=a.find(e=>"phone"===e.name),(i&&1===i.notnull||s&&1===s.notnull)&&n.transaction(()=>{n.exec("DROP TABLE IF EXISTS users__migration_backup"),n.exec(`
      CREATE TABLE users__migration_backup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `),n.exec(`
      INSERT INTO users__migration_backup (id, name, email, phone, password_hash, created_at)
      SELECT id, name, email, phone, password_hash, created_at FROM users;
    `),n.exec("DROP TABLE users;"),n.exec("ALTER TABLE users__migration_backup RENAME TO users;")})(),n.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),n.exec(`
  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),n.exec(`
  CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash
  ON password_resets(token_hash);
`),n.exec(`
  CREATE TABLE IF NOT EXISTS verification_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_type TEXT NOT NULL CHECK(target_type IN ('email', 'phone')),
    target_value TEXT NOT NULL,
    purpose TEXT NOT NULL DEFAULT 'register',
    code_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),n.exec(`
  CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup
  ON verification_codes(target_type, target_value, purpose, created_at DESC);
`),t.exports=n},2734,(e,t,r)=>{t.exports=e.x("fs",()=>require("fs"))},1880,(e,t,r)=>{let a=e.r(2734),i=e.r(4747),s=e.r(2692);t.exports=function(e,t){if("GET"!==e.method)return t.setHeader("Allow",["GET"]),t.status(405).json({error:"Method Not Allowed"});let{id:r}=e.query;if(!r)return t.status(400).json({error:"Missing file id"});let E=s.prepare("SELECT * FROM files WHERE id = ?").get(r);if(!E)return t.status(404).json({error:"File not found"});let n=i.join(process.cwd(),"uploads",E.stored_name);if(!a.existsSync(n))return t.status(404).json({error:"File missing on server"});t.setHeader("Content-Type",E.mime_type||"application/octet-stream"),t.setHeader("Content-Disposition",`attachment; filename="${encodeURIComponent(E.original_name)}"`),a.createReadStream(n).pipe(t)}},8199,e=>{"use strict";var t=e.i(6747),r=e.i(9245),a=e.i(4898),i=e.i(2950),s=e.i(1880),E=e.i(7031),n=e.i(1927),T=e.i(6432);let o=(0,i.hoist)(s,"default"),d=(0,i.hoist)(s,"config"),l=new a.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/files/download/[id]",pathname:"/api/files/download/[id]",bundlePath:"",filename:""},userland:s,distDir:".next",relativeProjectDir:""});async function p(e,r,a){l.isDev&&(0,T.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let i="/api/files/download/[id]";i=i.replace(/\/index$/,"")||"/";let s=await l.prepare(e,r,{srcPage:i});if(!s){r.statusCode=400,r.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:o,params:d,prerenderManifest:p,routerServerContext:u}=s;try{let t=e.method||"GET",a=(0,E.getTracer)(),s=a.getActiveScopeSpan(),T=l.instrumentationOnRequestError.bind(l),N=async s=>l.render(e,r,{query:{...o,...d},params:d,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:p.preview,propagateError:!1,dev:l.isDev,page:"/api/files/download/[id]",internalRevalidate:null==u?void 0:u.revalidate,onError:(...t)=>T(e,...t)}).finally(()=>{if(!s)return;s.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==n.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let E=e.get("next.route");if(E){let e=`${t} ${E}`;s.setAttributes({"next.route":E,"http.route":E,"next.span_name":e}),s.updateName(e)}else s.updateName(`${t} ${i}`)});s?await N(s):await a.withPropagatedContext(e.headers,()=>a.trace(n.BaseServerSpan.handleRequest,{spanName:`${t} ${i}`,kind:E.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},N))}catch(e){if(l.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,d,"default",0,o,"handler",()=>p])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0acee1c2._.js.map