module.exports=[406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},4747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},5372,(e,t,r)=>{t.exports=e.x("better-sqlite3",()=>require("better-sqlite3"))},2692,(e,t,r)=>{let a,s,i,n=e.r(4747),o=new(e.r(5372))(n.join(process.cwd(),"hpstudio.db"));o.pragma("journal_mode = WAL"),o.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),s=(a=o.prepare("PRAGMA table_info(users)").all()).find(e=>"email"===e.name),i=a.find(e=>"phone"===e.name),(s&&1===s.notnull||i&&1===i.notnull)&&o.transaction(()=>{o.exec("DROP TABLE IF EXISTS users__migration_backup"),o.exec(`
      CREATE TABLE users__migration_backup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `),o.exec(`
      INSERT INTO users__migration_backup (id, name, email, phone, password_hash, created_at)
      SELECT id, name, email, phone, password_hash, created_at FROM users;
    `),o.exec("DROP TABLE users;"),o.exec("ALTER TABLE users__migration_backup RENAME TO users;")})(),o.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),o.exec(`
  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),o.exec(`
  CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash
  ON password_resets(token_hash);
`),o.exec(`
  CREATE TABLE IF NOT EXISTS verification_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_type TEXT NOT NULL CHECK(target_type IN ('email', 'phone')),
    target_value TEXT NOT NULL,
    purpose TEXT NOT NULL DEFAULT 'register',
    code_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),o.exec(`
  CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup
  ON verification_codes(target_type, target_value, purpose, created_at DESC);
`),t.exports=o},8510,(e,t,r)=>{t.exports=e.x("bcryptjs",()=>require("bcryptjs"))},6187,(e,t,r)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},6890,(e,t,r)=>{t.exports=e.x("cookie",()=>require("cookie"))},3064,(e,t,r)=>{let a=e.r(8510),s=e.r(6187),i=e.r(6890),n=e.r(2692),o=process.env.JWT_SECRET||"CHANGE_ME_HP_STUDIO_SECRET",E="hpstudio_token",T=e=>({id:e.id,name:e.name,email:e.email,phone:e.phone,created_at:e.created_at});function u(e){if(!e)return null;try{let t=s.verify(e,o),r=n.prepare("SELECT * FROM users WHERE id = ?").get(t.id);return r?T(r):null}catch(e){return null}}function d(e){return e.headers.cookie&&i.parse(e.headers.cookie)[E]||null}t.exports={hashPassword:async function e(e){return a.hash(e,10)},verifyPassword:async function e(e,t){return a.compare(e,t)},signToken:function(e){return s.sign({id:e.id},o,{expiresIn:"7d"})},setAuthCookie:function(e,t){e.setHeader("Set-Cookie",i.serialize(E,t,{httpOnly:!0,secure:!0,sameSite:"lax",path:"/",maxAge:604800}))},clearAuthCookie:function(e){e.setHeader("Set-Cookie",i.serialize(E,"",{httpOnly:!0,secure:!0,sameSite:"lax",path:"/",maxAge:0}))},requireUser:function(e,t){let r=u(d(e));return r||(t.status(401).json({error:"Authentication required"}),null)},getUserFromToken:u,getTokenFromRequest:d,serializeUser:T}},9642,(e,t,r)=>{let a=e.r(2692),{verifyPassword:s,signToken:i,setAuthCookie:n,serializeUser:o}=e.r(3064);t.exports=async function(e,t){if("POST"!==e.method)return t.setHeader("Allow",["POST"]),t.status(405).json({error:"Method Not Allowed"});let{identifier:r,password:E}=e.body||{};if(!r||!E)return t.status(400).json({error:"Identifier and password are required"});try{let e=a.prepare("SELECT * FROM users WHERE email = ? OR phone = ?").get(r.trim().toLowerCase(),r.trim());if(!e||!await s(E,e.password_hash))return t.status(401).json({error:"Invalid credentials"});let T=o(e),u=i(T);return n(t,u),t.status(200).json({user:T})}catch(e){return console.error("Login error",e),t.status(500).json({error:"Login failed"})}}},6428,e=>{"use strict";var t=e.i(6747),r=e.i(9245),a=e.i(4898),s=e.i(2950),i=e.i(9642),n=e.i(7031),o=e.i(1927),E=e.i(6432);let T=(0,s.hoist)(i,"default"),u=(0,s.hoist)(i,"config"),d=new a.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/auth/login",pathname:"/api/auth/login",bundlePath:"",filename:""},userland:i,distDir:".next",relativeProjectDir:""});async function l(e,r,a){d.isDev&&(0,E.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let s="/api/auth/login";s=s.replace(/\/index$/,"")||"/";let i=await d.prepare(e,r,{srcPage:s});if(!i){r.statusCode=400,r.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:T,params:u,prerenderManifest:l,routerServerContext:p}=i;try{let t=e.method||"GET",a=(0,n.getTracer)(),i=a.getActiveScopeSpan(),E=d.instrumentationOnRequestError.bind(d),c=async i=>d.render(e,r,{query:{...T,...u},params:u,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:l.preview,propagateError:!1,dev:d.isDev,page:"/api/auth/login",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>E(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==o.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${t} ${n}`;i.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),i.updateName(e)}else i.updateName(`${t} ${s}`)});i?await c(i):await a.withPropagatedContext(e.headers,()=>a.trace(o.BaseServerSpan.handleRequest,{spanName:`${t} ${s}`,kind:n.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},c))}catch(e){if(d.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,u,"default",0,T,"handler",()=>l])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__63b97cc6._.js.map