module.exports=[406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},4747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},5372,(e,t,r)=>{t.exports=e.x("better-sqlite3",()=>require("better-sqlite3"))},2692,(e,t,r)=>{let s,a,i,n=e.r(4747),E=new(e.r(5372))(n.join(process.cwd(),"hpstudio.db"));E.pragma("journal_mode = WAL"),E.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),a=(s=E.prepare("PRAGMA table_info(users)").all()).find(e=>"email"===e.name),i=s.find(e=>"phone"===e.name),(a&&1===a.notnull||i&&1===i.notnull)&&E.transaction(()=>{E.exec("DROP TABLE IF EXISTS users__migration_backup"),E.exec(`
      CREATE TABLE users__migration_backup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `),E.exec(`
      INSERT INTO users__migration_backup (id, name, email, phone, password_hash, created_at)
      SELECT id, name, email, phone, password_hash, created_at FROM users;
    `),E.exec("DROP TABLE users;"),E.exec("ALTER TABLE users__migration_backup RENAME TO users;")})(),E.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),E.exec(`
  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),E.exec(`
  CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash
  ON password_resets(token_hash);
`),E.exec(`
  CREATE TABLE IF NOT EXISTS verification_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_type TEXT NOT NULL CHECK(target_type IN ('email', 'phone')),
    target_value TEXT NOT NULL,
    purpose TEXT NOT NULL DEFAULT 'register',
    code_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),E.exec(`
  CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup
  ON verification_codes(target_type, target_value, purpose, created_at DESC);
`),t.exports=E},4799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},8510,(e,t,r)=>{t.exports=e.x("bcryptjs",()=>require("bcryptjs"))},6187,(e,t,r)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},6890,(e,t,r)=>{t.exports=e.x("cookie",()=>require("cookie"))},3064,(e,t,r)=>{let s=e.r(8510),a=e.r(6187),i=e.r(6890),n=e.r(2692),E=process.env.JWT_SECRET||"CHANGE_ME_HP_STUDIO_SECRET",o="hpstudio_token",T=e=>({id:e.id,name:e.name,email:e.email,phone:e.phone,created_at:e.created_at});function u(e){if(!e)return null;try{let t=a.verify(e,E),r=n.prepare("SELECT * FROM users WHERE id = ?").get(t.id);return r?T(r):null}catch(e){return null}}function d(e){return e.headers.cookie&&i.parse(e.headers.cookie)[o]||null}t.exports={hashPassword:async function e(e){return s.hash(e,10)},verifyPassword:async function e(e,t){return s.compare(e,t)},signToken:function(e){return a.sign({id:e.id},E,{expiresIn:"7d"})},setAuthCookie:function(e,t){e.setHeader("Set-Cookie",i.serialize(o,t,{httpOnly:!0,secure:!0,sameSite:"lax",path:"/",maxAge:604800}))},clearAuthCookie:function(e){e.setHeader("Set-Cookie",i.serialize(o,"",{httpOnly:!0,secure:!0,sameSite:"lax",path:"/",maxAge:0}))},requireUser:function(e,t){let r=u(d(e));return r||(t.status(401).json({error:"Authentication required"}),null)},getUserFromToken:u,getTokenFromRequest:d,serializeUser:T}},263,(e,t,r)=>{let s=e.r(2692),{hashPassword:a}=e.r(3064),i=e.r(4799);t.exports=async function(e,t){var r;if("POST"!==e.method)return t.setHeader("Allow",["POST"]),t.status(405).json({error:"Method Not Allowed"});let{token:n,password:E}=e.body||{};if(!n||!E)return t.status(400).json({error:"重置令牌和新密码不能为空"});if(E.length<8)return t.status(400).json({error:"新密码至少需要 8 位字符"});let o=(r=n.trim(),i.createHash("sha256").update(r).digest("hex"));try{let e=s.prepare(`
      SELECT id, user_id, expires_at, used_at
      FROM password_resets
      WHERE token_hash = ?
        AND used_at IS NULL
        AND expires_at > CURRENT_TIMESTAMP
      ORDER BY id DESC
      LIMIT 1
    `).get(o);if(!e)return t.status(400).json({error:"重置链接无效或已过期"});let r=await a(E);return s.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(r,e.user_id),s.prepare("UPDATE password_resets SET used_at = CURRENT_TIMESTAMP WHERE id = ?").run(e.id),s.prepare("DELETE FROM password_resets WHERE user_id = ? AND (expires_at <= CURRENT_TIMESTAMP OR used_at IS NOT NULL)").run(e.user_id),t.status(200).json({message:"密码已更新，请重新登录"})}catch(e){return console.error("Reset password error",e),t.status(500).json({error:"重置失败"})}}},6943,e=>{"use strict";var t=e.i(6747),r=e.i(9245),s=e.i(4898),a=e.i(2950),i=e.i(263),n=e.i(7031),E=e.i(1927),o=e.i(6432);let T=(0,a.hoist)(i,"default"),u=(0,a.hoist)(i,"config"),d=new s.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/auth/reset",pathname:"/api/auth/reset",bundlePath:"",filename:""},userland:i,distDir:".next",relativeProjectDir:""});async function p(e,r,s){d.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/auth/reset";a=a.replace(/\/index$/,"")||"/";let i=await d.prepare(e,r,{srcPage:a});if(!i){r.statusCode=400,r.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:T,params:u,prerenderManifest:p,routerServerContext:l}=i;try{let t=e.method||"GET",s=(0,n.getTracer)(),i=s.getActiveScopeSpan(),o=d.instrumentationOnRequestError.bind(d),c=async i=>d.render(e,r,{query:{...T,...u},params:u,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:p.preview,propagateError:!1,dev:d.isDev,page:"/api/auth/reset",internalRevalidate:null==l?void 0:l.revalidate,onError:(...t)=>o(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==E.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${t} ${n}`;i.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),i.updateName(e)}else i.updateName(`${t} ${a}`)});i?await c(i):await s.withPropagatedContext(e.headers,()=>s.trace(E.BaseServerSpan.handleRequest,{spanName:`${t} ${a}`,kind:n.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},c))}catch(e){if(d.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,u,"default",0,T,"handler",()=>p])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__955a1466._.js.map