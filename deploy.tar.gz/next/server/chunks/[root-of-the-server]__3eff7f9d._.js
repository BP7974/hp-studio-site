module.exports=[406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},4747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},5372,(e,t,r)=>{t.exports=e.x("better-sqlite3",()=>require("better-sqlite3"))},2692,(e,t,r)=>{let a,i,s,o=e.r(4747),n=new(e.r(5372))(o.join(process.cwd(),"hpstudio.db"));n.pragma("journal_mode = WAL"),n.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),i=(a=n.prepare("PRAGMA table_info(users)").all()).find(e=>"email"===e.name),s=a.find(e=>"phone"===e.name),(i&&1===i.notnull||s&&1===s.notnull)&&n.transaction(()=>{n.exec("DROP TABLE IF EXISTS users__migration_backup"),n.exec(`
      CREATE TABLE users__migration_backup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `),n.exec(`
      INSERT INTO users__migration_backup (id, name, email, phone, password_hash, created_at)
      SELECT id, name, email, phone, password_hash, created_at FROM users;
    `),n.exec("DROP TABLE users;"),n.exec("ALTER TABLE users__migration_backup RENAME TO users;")})(),n.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),n.exec(`
  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),n.exec(`
  CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash
  ON password_resets(token_hash);
`),n.exec(`
  CREATE TABLE IF NOT EXISTS verification_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_type TEXT NOT NULL CHECK(target_type IN ('email', 'phone')),
    target_value TEXT NOT NULL,
    purpose TEXT NOT NULL DEFAULT 'register',
    code_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),n.exec(`
  CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup
  ON verification_codes(target_type, target_value, purpose, created_at DESC);
`),t.exports=n},4799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},7530,(e,t,r)=>{let a=e.r(4799),i=e.r(2692),s=Number(process.env.VERIFICATION_CODE_TTL_MINUTES||10),o=Number(process.env.VR_CODE_RESEND_SECONDS||process.env.VERIFICATION_RESEND_SECONDS||60),n=Number(process.env.VERIFICATION_CODE_LENGTH||6);function E(e,t){return t?"email"===e?String(t).trim().toLowerCase():String(t).trim():""}function T(e){return a.createHash("sha256").update(String(e)).digest("hex")}function u(e=n){let t="";for(let r=0;r<e;r+=1)t+=a.randomInt(0,10);return t}t.exports={createVerificationCode:function({targetType:e,targetValue:t,purpose:r="register",ttlMinutes:a=s,resendSeconds:n=o}){if(!["email","phone"].includes(e))throw Error("Unsupported target type");let p=E(e,t);if(!p)throw Error("Target value is required");!function(e,t,r,a){let s=i.prepare(`SELECT created_at FROM verification_codes
       WHERE target_type = ? AND target_value = ? AND purpose = ?
       AND used_at IS NULL
       ORDER BY created_at DESC
       LIMIT 1`).get(e,t,r);if(!s)return;let o=new Date(s.created_at).getTime(),n=(Date.now()-o)/1e3;if(n<a){let e=Math.ceil(a-n),t=Error(`请等待 ${e} 秒后再请求验证码`);throw t.code="RATE_LIMIT",t.retryAfter=e,t}}(e,p,r,n);let d=u(),l=new Date(Date.now()+60*a*1e3).toISOString(),c=T(d);return i.prepare(`INSERT INTO verification_codes (target_type, target_value, purpose, code_hash, expires_at)
     VALUES (?, ?, ?, ?, ?)`).run(e,p,r,c,l),{code:d,expiresAt:l}},verifyVerificationCode:function({targetType:e,targetValue:t,code:r,purpose:a="register",consume:s=!0}){if(!r)throw Error("验证码不能为空");let o=E(e,t),n=i.prepare(`SELECT id, code_hash, expires_at, used_at FROM verification_codes
       WHERE target_type = ? AND target_value = ? AND purpose = ?
       ORDER BY created_at DESC
       LIMIT 1`).get(e,o,a);if(!n)throw Error("请先获取验证码");if(n.used_at)throw Error("验证码已被使用，请重新获取");if(new Date(n.expires_at).getTime()<Date.now())throw Error("验证码已过期");if(T(r)!==n.code_hash)throw Error("验证码不正确");return s&&i.prepare("UPDATE verification_codes SET used_at = CURRENT_TIMESTAMP WHERE id = ?").run(n.id),!0},normalizeTarget:E,generateNumericCode:u}},8712,(e,t,r)=>{t.exports=e.x("nodemailer",()=>require("nodemailer"))},5066,(e,t,r)=>{let a=e.r(8712),i=null,s=null,o=Number(process.env.VERIFICATION_CODE_TTL_MINUTES||10);function n(){let{SMTP_HOST:e,SMTP_PORT:t,SMTP_SECURE:r,SMTP_USER:a,SMTP_PASS:i,SMTP_FROM:s}=process.env;if(!e||!a||!i||!s)return null;let o=Number(t||465),n="string"==typeof r?!["0","false","False","FALSE"].includes(r):465===o;return{host:e,port:o,secure:n,auth:{user:a,pass:i},from:s}}function E(){let e=n();if(!e)return i=null,s=null,null;let{from:t,...r}=e,o=JSON.stringify(r);return i&&o===s||(i=a.createTransport(r),s=o),i}t.exports={sendPasswordResetEmail:async function({to:e,resetUrl:t,token:r}){let a=E(),i=n();if(!a||!i)throw Error("SMTP is not configured");let s=`你正在请求重置 HP Studio 账号的密码。
重置链接：${t}
如果不是你本人操作，请忽略此邮件。`,o=`
    <p>你正在请求重置 HP Studio 账号的密码。</p>
    <p>点击以下链接即可完成重置（${process.env.PASSWORD_RESET_TTL_MINUTES||60} 分钟内有效）：</p>
    <p><a href="${t}">${t}</a></p>
    <p>如果不是你本人操作，请忽略此邮件。</p>
    <p style="color:#666;font-size:12px;">如果无法点击链接，可复制令牌：<code>${r}</code></p>
  `;await a.sendMail({from:i.from,to:e,subject:"HP Studio 密码重置",text:s,html:o})},sendVerificationEmail:async function({to:e,code:t,ttlMinutes:r=o,subject:a,text:i,html:s}){let T=E(),u=n();if(!T||!u)throw Error("SMTP is not configured");let p=i||`您的验证码是 ${t}，${r} 分钟内有效，请勿泄露给他人。`,d=s||`
    <p>您的 HP Studio 注册验证码：</p>
    <p style="font-size:24px;font-weight:bold;letter-spacing:2px;">${t}</p>
    <p>请在 ${r} 分钟内完成输入，该验证码仅供一次性使用。</p>
  `;await T.sendMail({from:u.from,to:e,subject:a||"HP Studio 注册验证码",text:p,html:d})},isSmtpConfigured:function(){return!!E()}}},4119,(e,t,r)=>{let a=e.r(2692),{createVerificationCode:i}=e.r(7530),{isSmtpConfigured:s,sendVerificationEmail:o}=e.r(5066),n=Number(process.env.VERIFICATION_CODE_TTL_MINUTES||10),E=Number(process.env.VERIFICATION_RESEND_SECONDS||process.env.VR_CODE_RESEND_SECONDS||60);t.exports=async function(e,t){if("POST"!==e.method)return t.setHeader("Allow",["POST"]),t.status(405).json({error:"Method Not Allowed"});let{email:r}=e.body||{},T=String(r||"").trim().toLowerCase();if(!T)return t.status(400).json({error:"请输入邮箱"});if(a.prepare("SELECT id FROM users WHERE email = ?").get(T))return t.status(409).json({error:"该邮箱已注册"});try{let{code:e,expiresAt:r}=i({targetType:"email",targetValue:T,purpose:"register-email",ttlMinutes:n}),a="preview";s()&&(await o({to:T,code:e,ttlMinutes:n}),a="email");let u={message:"邮箱验证码已发送",expiresAt:r,delivery:a,cooldown:E};return"email"!==a&&(u.previewCode=e),t.status(200).json(u)}catch(e){if("RATE_LIMIT"===e.code)return t.status(429).json({error:e.message,retryAfter:e.retryAfter});return console.error("send-email-code error",e),t.status(500).json({error:"发送失败，请稍后再试"})}}},2704,e=>{"use strict";var t=e.i(6747),r=e.i(9245),a=e.i(4898),i=e.i(2950),s=e.i(4119),o=e.i(7031),n=e.i(1927),E=e.i(6432);let T=(0,i.hoist)(s,"default"),u=(0,i.hoist)(s,"config"),p=new a.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/auth/send-email-code",pathname:"/api/auth/send-email-code",bundlePath:"",filename:""},userland:s,distDir:".next",relativeProjectDir:""});async function d(e,r,a){p.isDev&&(0,E.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let i="/api/auth/send-email-code";i=i.replace(/\/index$/,"")||"/";let s=await p.prepare(e,r,{srcPage:i});if(!s){r.statusCode=400,r.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:T,params:u,prerenderManifest:d,routerServerContext:l}=s;try{let t=e.method||"GET",a=(0,o.getTracer)(),s=a.getActiveScopeSpan(),E=p.instrumentationOnRequestError.bind(p),c=async s=>p.render(e,r,{query:{...T,...u},params:u,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:d.preview,propagateError:!1,dev:p.isDev,page:"/api/auth/send-email-code",internalRevalidate:null==l?void 0:l.revalidate,onError:(...t)=>E(e,...t)}).finally(()=>{if(!s)return;s.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==n.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let o=e.get("next.route");if(o){let e=`${t} ${o}`;s.setAttributes({"next.route":o,"http.route":o,"next.span_name":e}),s.updateName(e)}else s.updateName(`${t} ${i}`)});s?await c(s):await a.withPropagatedContext(e.headers,()=>a.trace(n.BaseServerSpan.handleRequest,{spanName:`${t} ${i}`,kind:o.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},c))}catch(e){if(p.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,u,"default",0,T,"handler",()=>d])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__3eff7f9d._.js.map