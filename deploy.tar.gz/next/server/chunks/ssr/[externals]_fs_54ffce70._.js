module.exports=[2734,(a,b,c)=>{b.exports=a.x("fs",()=>require("fs"))}];

//# sourceMappingURL=%5Bexternals%5D_fs_54ffce70._.js.map