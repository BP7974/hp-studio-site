module.exports=[4747,(a,b,c)=>{b.exports=a.x("path",()=>require("path"))},406,(a,b,c)=>{b.exports=a.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__b00fd6f7._.js.map