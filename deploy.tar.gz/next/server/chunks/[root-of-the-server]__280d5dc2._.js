module.exports=[8510,(e,t,r)=>{t.exports=e.x("bcryptjs",()=>require("bcryptjs"))},6187,(e,t,r)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},6890,(e,t,r)=>{t.exports=e.x("cookie",()=>require("cookie"))},3064,(e,t,r)=>{let a=e.r(8510),i=e.r(6187),s=e.r(6890),n=e.r(2692),o=process.env.JWT_SECRET||"CHANGE_ME_HP_STUDIO_SECRET",E="hpstudio_token",T=e=>({id:e.id,name:e.name,email:e.email,phone:e.phone,created_at:e.created_at});function u(e){if(!e)return null;try{let t=i.verify(e,o),r=n.prepare("SELECT * FROM users WHERE id = ?").get(t.id);return r?T(r):null}catch(e){return null}}function p(e){return e.headers.cookie&&s.parse(e.headers.cookie)[E]||null}t.exports={hashPassword:async function e(e){return a.hash(e,10)},verifyPassword:async function e(e,t){return a.compare(e,t)},signToken:function(e){return i.sign({id:e.id},o,{expiresIn:"7d"})},setAuthCookie:function(e,t){e.setHeader("Set-Cookie",s.serialize(E,t,{httpOnly:!0,secure:!0,sameSite:"lax",path:"/",maxAge:604800}))},clearAuthCookie:function(e){e.setHeader("Set-Cookie",s.serialize(E,"",{httpOnly:!0,secure:!0,sameSite:"lax",path:"/",maxAge:0}))},requireUser:function(e,t){let r=u(p(e));return r||(t.status(401).json({error:"Authentication required"}),null)},getUserFromToken:u,getTokenFromRequest:p,serializeUser:T}},406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},4747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},5372,(e,t,r)=>{t.exports=e.x("better-sqlite3",()=>require("better-sqlite3"))},2692,(e,t,r)=>{let a,i,s,n=e.r(4747),o=new(e.r(5372))(n.join(process.cwd(),"hpstudio.db"));o.pragma("journal_mode = WAL"),o.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),i=(a=o.prepare("PRAGMA table_info(users)").all()).find(e=>"email"===e.name),s=a.find(e=>"phone"===e.name),(i&&1===i.notnull||s&&1===s.notnull)&&o.transaction(()=>{o.exec("DROP TABLE IF EXISTS users__migration_backup"),o.exec(`
      CREATE TABLE users__migration_backup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `),o.exec(`
      INSERT INTO users__migration_backup (id, name, email, phone, password_hash, created_at)
      SELECT id, name, email, phone, password_hash, created_at FROM users;
    `),o.exec("DROP TABLE users;"),o.exec("ALTER TABLE users__migration_backup RENAME TO users;")})(),o.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),o.exec(`
  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),o.exec(`
  CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash
  ON password_resets(token_hash);
`),o.exec(`
  CREATE TABLE IF NOT EXISTS verification_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_type TEXT NOT NULL CHECK(target_type IN ('email', 'phone')),
    target_value TEXT NOT NULL,
    purpose TEXT NOT NULL DEFAULT 'register',
    code_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),o.exec(`
  CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup
  ON verification_codes(target_type, target_value, purpose, created_at DESC);
`),t.exports=o},4799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},7530,(e,t,r)=>{let a=e.r(4799),i=e.r(2692),s=Number(process.env.VERIFICATION_CODE_TTL_MINUTES||10),n=Number(process.env.VR_CODE_RESEND_SECONDS||process.env.VERIFICATION_RESEND_SECONDS||60),o=Number(process.env.VERIFICATION_CODE_LENGTH||6);function E(e,t){return t?"email"===e?String(t).trim().toLowerCase():String(t).trim():""}function T(e){return a.createHash("sha256").update(String(e)).digest("hex")}function u(e=o){let t="";for(let r=0;r<e;r+=1)t+=a.randomInt(0,10);return t}t.exports={createVerificationCode:function({targetType:e,targetValue:t,purpose:r="register",ttlMinutes:a=s,resendSeconds:o=n}){if(!["email","phone"].includes(e))throw Error("Unsupported target type");let p=E(e,t);if(!p)throw Error("Target value is required");!function(e,t,r,a){let s=i.prepare(`SELECT created_at FROM verification_codes
       WHERE target_type = ? AND target_value = ? AND purpose = ?
       AND used_at IS NULL
       ORDER BY created_at DESC
       LIMIT 1`).get(e,t,r);if(!s)return;let n=new Date(s.created_at).getTime(),o=(Date.now()-n)/1e3;if(o<a){let e=Math.ceil(a-o),t=Error(`请等待 ${e} 秒后再请求验证码`);throw t.code="RATE_LIMIT",t.retryAfter=e,t}}(e,p,r,o);let l=u(),d=new Date(Date.now()+60*a*1e3).toISOString(),c=T(l);return i.prepare(`INSERT INTO verification_codes (target_type, target_value, purpose, code_hash, expires_at)
     VALUES (?, ?, ?, ?, ?)`).run(e,p,r,c,d),{code:l,expiresAt:d}},verifyVerificationCode:function({targetType:e,targetValue:t,code:r,purpose:a="register",consume:s=!0}){if(!r)throw Error("验证码不能为空");let n=E(e,t),o=i.prepare(`SELECT id, code_hash, expires_at, used_at FROM verification_codes
       WHERE target_type = ? AND target_value = ? AND purpose = ?
       ORDER BY created_at DESC
       LIMIT 1`).get(e,n,a);if(!o)throw Error("请先获取验证码");if(o.used_at)throw Error("验证码已被使用，请重新获取");if(new Date(o.expires_at).getTime()<Date.now())throw Error("验证码已过期");if(T(r)!==o.code_hash)throw Error("验证码不正确");return s&&i.prepare("UPDATE verification_codes SET used_at = CURRENT_TIMESTAMP WHERE id = ?").run(o.id),!0},normalizeTarget:E,generateNumericCode:u}},4979,(e,t,r)=>{let a=e.r(2692),{hashPassword:i,signToken:s,setAuthCookie:n,serializeUser:o}=e.r(3064),{verifyVerificationCode:E}=e.r(7530);t.exports=async function(e,t){if("POST"!==e.method)return t.setHeader("Allow",["POST"]),t.status(405).json({error:"Method Not Allowed"});let{name:r,email:T,phone:u,password:p,emailCode:l,phoneCode:d}=e.body||{};if(!r||!p)return t.status(400).json({error:"请输入姓名和密码"});let c=!!(T&&String(T).trim()),_=!!(u&&String(u).trim());if(!c&&!_)return t.status(400).json({error:"请至少填写邮箱或手机号"});if(c&&!l)return t.status(400).json({error:"请输入邮箱验证码"});if(_&&!d)return t.status(400).json({error:"请输入短信验证码"});let N=c?String(T).trim().toLowerCase():null,h=_?String(u).trim():null;try{let e=null,T=[],u=[];if(c&&(T.push("email = ?"),u.push(N)),_&&(T.push("phone = ?"),u.push(h)),T.length&&(e=a.prepare(`SELECT id FROM users WHERE ${T.join(" OR ")}`).get(...u)),e)return t.status(409).json({error:"Email or phone already registered"});try{c&&E({targetType:"email",targetValue:N,code:l,purpose:"register-email"}),_&&E({targetType:"phone",targetValue:h,code:d,purpose:"register-phone"})}catch(e){return t.status(400).json({error:e.message||"验证码校验失败"})}let R=await i(p),I=a.prepare("INSERT INTO users (name, email, phone, password_hash) VALUES (?, ?, ?, ?)").run(r.trim(),N||null,h||null,R),A=o({id:I.lastInsertRowid,name:r.trim(),email:N,phone:h,created_at:new Date().toISOString()}),m=s(A);return n(t,m),t.status(201).json({user:A})}catch(e){return console.error("Register error",e),t.status(500).json({error:"Registration failed"})}}},1995,e=>{"use strict";var t=e.i(6747),r=e.i(9245),a=e.i(4898),i=e.i(2950),s=e.i(4979),n=e.i(7031),o=e.i(1927),E=e.i(6432);let T=(0,i.hoist)(s,"default"),u=(0,i.hoist)(s,"config"),p=new a.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/auth/register",pathname:"/api/auth/register",bundlePath:"",filename:""},userland:s,distDir:".next",relativeProjectDir:""});async function l(e,r,a){p.isDev&&(0,E.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let i="/api/auth/register";i=i.replace(/\/index$/,"")||"/";let s=await p.prepare(e,r,{srcPage:i});if(!s){r.statusCode=400,r.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:T,params:u,prerenderManifest:l,routerServerContext:d}=s;try{let t=e.method||"GET",a=(0,n.getTracer)(),s=a.getActiveScopeSpan(),E=p.instrumentationOnRequestError.bind(p),c=async s=>p.render(e,r,{query:{...T,...u},params:u,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:l.preview,propagateError:!1,dev:p.isDev,page:"/api/auth/register",internalRevalidate:null==d?void 0:d.revalidate,onError:(...t)=>E(e,...t)}).finally(()=>{if(!s)return;s.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==o.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${t} ${n}`;s.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),s.updateName(e)}else s.updateName(`${t} ${i}`)});s?await c(s):await a.withPropagatedContext(e.headers,()=>a.trace(o.BaseServerSpan.handleRequest,{spanName:`${t} ${i}`,kind:n.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},c))}catch(e){if(p.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,u,"default",0,T,"handler",()=>l])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__280d5dc2._.js.map