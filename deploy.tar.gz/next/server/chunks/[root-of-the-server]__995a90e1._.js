module.exports=[406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},4747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},5372,(e,t,r)=>{t.exports=e.x("better-sqlite3",()=>require("better-sqlite3"))},2692,(e,t,r)=>{let s,o,a,i=e.r(4747),n=new(e.r(5372))(i.join(process.cwd(),"hpstudio.db"));n.pragma("journal_mode = WAL"),n.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),o=(s=n.prepare("PRAGMA table_info(users)").all()).find(e=>"email"===e.name),a=s.find(e=>"phone"===e.name),(o&&1===o.notnull||a&&1===a.notnull)&&n.transaction(()=>{n.exec("DROP TABLE IF EXISTS users__migration_backup"),n.exec(`
      CREATE TABLE users__migration_backup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `),n.exec(`
      INSERT INTO users__migration_backup (id, name, email, phone, password_hash, created_at)
      SELECT id, name, email, phone, password_hash, created_at FROM users;
    `),n.exec("DROP TABLE users;"),n.exec("ALTER TABLE users__migration_backup RENAME TO users;")})(),n.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),n.exec(`
  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),n.exec(`
  CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash
  ON password_resets(token_hash);
`),n.exec(`
  CREATE TABLE IF NOT EXISTS verification_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_type TEXT NOT NULL CHECK(target_type IN ('email', 'phone')),
    target_value TEXT NOT NULL,
    purpose TEXT NOT NULL DEFAULT 'register',
    code_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),n.exec(`
  CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup
  ON verification_codes(target_type, target_value, purpose, created_at DESC);
`),t.exports=n},4799,(e,t,r)=>{t.exports=e.x("crypto",()=>require("crypto"))},7530,(e,t,r)=>{let s=e.r(4799),o=e.r(2692),a=Number(process.env.VERIFICATION_CODE_TTL_MINUTES||10),i=Number(process.env.VR_CODE_RESEND_SECONDS||process.env.VERIFICATION_RESEND_SECONDS||60),n=Number(process.env.VERIFICATION_CODE_LENGTH||6);function E(e,t){return t?"email"===e?String(t).trim().toLowerCase():String(t).trim():""}function T(e){return s.createHash("sha256").update(String(e)).digest("hex")}function u(e=n){let t="";for(let r=0;r<e;r+=1)t+=s.randomInt(0,10);return t}t.exports={createVerificationCode:function({targetType:e,targetValue:t,purpose:r="register",ttlMinutes:s=a,resendSeconds:n=i}){if(!["email","phone"].includes(e))throw Error("Unsupported target type");let p=E(e,t);if(!p)throw Error("Target value is required");!function(e,t,r,s){let a=o.prepare(`SELECT created_at FROM verification_codes
       WHERE target_type = ? AND target_value = ? AND purpose = ?
       AND used_at IS NULL
       ORDER BY created_at DESC
       LIMIT 1`).get(e,t,r);if(!a)return;let i=new Date(a.created_at).getTime(),n=(Date.now()-i)/1e3;if(n<s){let e=Math.ceil(s-n),t=Error(`请等待 ${e} 秒后再请求验证码`);throw t.code="RATE_LIMIT",t.retryAfter=e,t}}(e,p,r,n);let l=u(),c=new Date(Date.now()+60*s*1e3).toISOString(),d=T(l);return o.prepare(`INSERT INTO verification_codes (target_type, target_value, purpose, code_hash, expires_at)
     VALUES (?, ?, ?, ?, ?)`).run(e,p,r,d,c),{code:l,expiresAt:c}},verifyVerificationCode:function({targetType:e,targetValue:t,code:r,purpose:s="register",consume:a=!0}){if(!r)throw Error("验证码不能为空");let i=E(e,t),n=o.prepare(`SELECT id, code_hash, expires_at, used_at FROM verification_codes
       WHERE target_type = ? AND target_value = ? AND purpose = ?
       ORDER BY created_at DESC
       LIMIT 1`).get(e,i,s);if(!n)throw Error("请先获取验证码");if(n.used_at)throw Error("验证码已被使用，请重新获取");if(new Date(n.expires_at).getTime()<Date.now())throw Error("验证码已过期");if(T(r)!==n.code_hash)throw Error("验证码不正确");return a&&o.prepare("UPDATE verification_codes SET used_at = CURRENT_TIMESTAMP WHERE id = ?").run(n.id),!0},normalizeTarget:E,generateNumericCode:u}},6610,(e,t,r)=>{t.exports=e.x("twilio",()=>require("twilio"))},6512,(e,t,r)=>{t.exports=e.x("@alicloud/pop-core",()=>require("@alicloud/pop-core"))},1725,(e,t,r)=>{let s=null,o=null;function a(){let{SPUG_SMS_ENDPOINT:e,SPUG_SMS_BASE_URL:t,SPUG_SMS_PATH:r,SPUG_SMS_TEMPLATE_ID:s}=process.env;if(e)return e;if(t&&(r||s))try{let e=r||`/send/${s}`;return new URL(e,t).toString()}catch(e){console.warn("[SMS] 无法解析 SPUG URL：",e.message)}return null}function i(){return"spug"===n()&&!!(process.env.SPUG_SMS_TOKEN&&a())}function n(){return(process.env.SMS_PROVIDER||"").toLowerCase()}function E(){if("twilio"!==n())return null;let{SMS_TWILIO_ACCOUNT_SID:t,SMS_TWILIO_AUTH_TOKEN:r}=process.env;return t&&r?(s||(s=e.r(6610)(t,r)),s):null}function T(){if("aliyun"!==n())return null;let{SMS_ALIYUN_ACCESS_KEY_ID:t,SMS_ALIYUN_ACCESS_KEY_SECRET:r}=process.env;return t&&r?(o||(o=new(e.r(6512))({accessKeyId:t,accessKeySecret:r,endpoint:"https://dysmsapi.aliyuncs.com",apiVersion:"2017-05-25"})),o):null}async function u({phone:e,code:t,ttlMinutes:r}){if(!i())throw Error("Spug SMS 未配置完整");let s=a(),{SPUG_SMS_TOKEN:o,SPUG_SMS_AUTH_SCHEME:n="Token",SPUG_SMS_TIMEOUT_MS:E=8e3,SPUG_SMS_HEADERS_JSON:T,SPUG_SMS_NAME:u="HP Studio",SPUG_SMS_EXTRA_JSON:p}=process.env,l={"Content-Type":"application/json"};if(o&&(l.Authorization=`${n||"Token"} ${o}`.trim()),T)try{Object.assign(l,JSON.parse(T))}catch(e){console.warn("[SMS] 解析 SPUG_SMS_HEADERS_JSON 失败：",e.message)}let c={name:u||"HP Studio",code:t,targets:e};if(p)try{Object.assign(c,JSON.parse(p))}catch(e){console.warn("[SMS] 解析 SPUG_SMS_EXTRA_JSON 失败：",e.message)}let d=new AbortController,_=setTimeout(()=>d.abort(),Number(E)||8e3);try{let e=await fetch(s,{method:"POST",headers:l,body:JSON.stringify(c),signal:d.signal});if(!e.ok){let t=await e.text();throw Error(`Spug SMS 接口异常：${e.status} ${t}`)}}finally{clearTimeout(_)}return{provider:"spug"}}t.exports={sendSmsVerification:async function({phone:e,code:t,ttlMinutes:r,messageTemplate:s}){var o,a;let i=n(),p=(o=s||"【HP Studio】验证码 {code}，{ttl} 分钟内有效，请勿泄露。",Object.keys(a={code:t,ttl:r}).reduce((e,t)=>e.replace(RegExp(`{${t}}`,"g"),a[t]),o));if("twilio"===i){let t=E();if(!t||!process.env.SMS_TWILIO_FROM)throw Error("Twilio SMS 未配置完整");return await t.messages.create({to:e,from:process.env.SMS_TWILIO_FROM,body:p}),{provider:"twilio"}}if("aliyun"===i){let s=T();if(!s||!process.env.SMS_ALIYUN_SIGN_NAME||!process.env.SMS_ALIYUN_TEMPLATE_CODE)throw Error("阿里云短信未配置完整");let o={RegionId:process.env.SMS_ALIYUN_REGION_ID||"cn-hangzhou",PhoneNumbers:e,SignName:process.env.SMS_ALIYUN_SIGN_NAME,TemplateCode:process.env.SMS_ALIYUN_TEMPLATE_CODE,TemplateParam:JSON.stringify({code:t,ttl:r})};return await s.request("SendSms",o,{method:"POST"}),{provider:"aliyun"}}return"spug"===i?u({phone:e,code:t,ttlMinutes:r}):(console.info(`[SMS MOCK] 向 ${e} 发送验证码 ${t}`),{provider:"mock",previewCode:t})},isSmsConfigured:function(){return!!(E()||T()||i())}}},6311,(e,t,r)=>{let s=e.r(2692),{createVerificationCode:o}=e.r(7530),{isSmsConfigured:a,sendSmsVerification:i}=e.r(1725),n=Number(process.env.VERIFICATION_CODE_TTL_MINUTES||10),E=Number(process.env.VERIFICATION_RESEND_SECONDS||process.env.VR_CODE_RESEND_SECONDS||60);t.exports=async function(e,t){if("POST"!==e.method)return t.setHeader("Allow",["POST"]),t.status(405).json({error:"Method Not Allowed"});let{phone:r}=e.body||{},T=String(r||"").trim();if(!/^\+?\d{6,20}$/.test(T))return t.status(400).json({error:"请输入正确的手机号（仅数字，可包含国家区号）"});if(s.prepare("SELECT id FROM users WHERE phone = ?").get(T))return t.status(409).json({error:"该手机号已注册"});try{let{code:e,expiresAt:r}=o({targetType:"phone",targetValue:T,purpose:"register-phone",ttlMinutes:n}),s="preview";a()&&(await i({phone:T,code:e,ttlMinutes:n}),s="sms");let u={message:"短信验证码已发送",expiresAt:r,delivery:s,cooldown:E};return"sms"!==s&&(u.previewCode=e),t.status(200).json(u)}catch(e){if("RATE_LIMIT"===e.code)return t.status(429).json({error:e.message,retryAfter:e.retryAfter});return console.error("send-phone-code error",e),t.status(500).json({error:"短信发送失败，请稍后再试"})}}},6233,e=>{"use strict";var t=e.i(6747),r=e.i(9245),s=e.i(4898),o=e.i(2950),a=e.i(6311),i=e.i(7031),n=e.i(1927),E=e.i(6432);let T=(0,o.hoist)(a,"default"),u=(0,o.hoist)(a,"config"),p=new s.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/auth/send-phone-code",pathname:"/api/auth/send-phone-code",bundlePath:"",filename:""},userland:a,distDir:".next",relativeProjectDir:""});async function l(e,r,s){p.isDev&&(0,E.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let o="/api/auth/send-phone-code";o=o.replace(/\/index$/,"")||"/";let a=await p.prepare(e,r,{srcPage:o});if(!a){r.statusCode=400,r.end("Bad Request"),null==s.waitUntil||s.waitUntil.call(s,Promise.resolve());return}let{query:T,params:u,prerenderManifest:l,routerServerContext:c}=a;try{let t=e.method||"GET",s=(0,i.getTracer)(),a=s.getActiveScopeSpan(),E=p.instrumentationOnRequestError.bind(p),d=async a=>p.render(e,r,{query:{...T,...u},params:u,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:l.preview,propagateError:!1,dev:p.isDev,page:"/api/auth/send-phone-code",internalRevalidate:null==c?void 0:c.revalidate,onError:(...t)=>E(e,...t)}).finally(()=>{if(!a)return;a.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=s.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==n.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=e.get("next.route");if(i){let e=`${t} ${i}`;a.setAttributes({"next.route":i,"http.route":i,"next.span_name":e}),a.updateName(e)}else a.updateName(`${t} ${o}`)});a?await d(a):await s.withPropagatedContext(e.headers,()=>s.trace(n.BaseServerSpan.handleRequest,{spanName:`${t} ${o}`,kind:i.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},d))}catch(e){if(p.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==s.waitUntil||s.waitUntil.call(s,Promise.resolve())}}e.s(["config",0,u,"default",0,T,"handler",()=>l])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__995a90e1._.js.map