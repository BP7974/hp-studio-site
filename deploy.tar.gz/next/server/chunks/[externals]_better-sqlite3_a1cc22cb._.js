module.exports=[5372,(e,t,r)=>{t.exports=e.x("better-sqlite3",()=>require("better-sqlite3"))}];

//# sourceMappingURL=%5Bexternals%5D_better-sqlite3_a1cc22cb._.js.map