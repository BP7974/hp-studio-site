module.exports=[406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},4747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},5372,(e,t,r)=>{t.exports=e.x("better-sqlite3",()=>require("better-sqlite3"))},2692,(e,t,r)=>{let a,s,i,E=e.r(4747),T=new(e.r(5372))(E.join(process.cwd(),"hpstudio.db"));T.pragma("journal_mode = WAL"),T.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),s=(a=T.prepare("PRAGMA table_info(users)").all()).find(e=>"email"===e.name),i=a.find(e=>"phone"===e.name),(s&&1===s.notnull||i&&1===i.notnull)&&T.transaction(()=>{T.exec("DROP TABLE IF EXISTS users__migration_backup"),T.exec(`
      CREATE TABLE users__migration_backup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `),T.exec(`
      INSERT INTO users__migration_backup (id, name, email, phone, password_hash, created_at)
      SELECT id, name, email, phone, password_hash, created_at FROM users;
    `),T.exec("DROP TABLE users;"),T.exec("ALTER TABLE users__migration_backup RENAME TO users;")})(),T.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),T.exec(`
  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),T.exec(`
  CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash
  ON password_resets(token_hash);
`),T.exec(`
  CREATE TABLE IF NOT EXISTS verification_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_type TEXT NOT NULL CHECK(target_type IN ('email', 'phone')),
    target_value TEXT NOT NULL,
    purpose TEXT NOT NULL DEFAULT 'register',
    code_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),T.exec(`
  CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup
  ON verification_codes(target_type, target_value, purpose, created_at DESC);
`),t.exports=T},6582,e=>{"use strict";var t=e.i(6747),r=e.i(9245),a=e.i(4898),s=e.i(2950),i=e.i(5372),E=e.i(4747);function T(e,t){let r=E.default.join(process.cwd(),"data","filemeta.db"),a=new i.default(r),s=a.prepare("SELECT * FROM files ORDER BY uploadtime DESC").all();a.close(),t.status(200).json({files:s})}let n=e.r(2692);module.exports=function(e,t){if("GET"!==e.method)return t.setHeader("Allow",["GET"]),t.status(405).json({error:"Method Not Allowed"});try{let e=n.prepare(`
      SELECT files.id, files.title, files.description, files.original_name,
             files.mime_type, files.size, files.created_at,
             users.name as uploader
      FROM files
      JOIN users ON users.id = files.user_id
      ORDER BY files.created_at DESC
      LIMIT 200
    `).all().map(e=>({...e,downloadUrl:`/api/files/download/${e.id}`}));return t.status(200).json({files:e})}catch(e){return console.error("List files error",e),t.status(500).json({error:"Unable to load files"})}},e.s(["default",()=>T],957);var o=e.i(957),l=e.i(7031),d=e.i(1927),p=e.i(6432);let u=(0,s.hoist)(o,"default"),N=(0,s.hoist)(o,"config"),_=new a.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/files/list",pathname:"/api/files/list",bundlePath:"",filename:""},userland:o,distDir:".next",relativeProjectDir:""});async function c(e,r,a){_.isDev&&(0,p.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let s="/api/files/list";s=s.replace(/\/index$/,"")||"/";let i=await _.prepare(e,r,{srcPage:s});if(!i){r.statusCode=400,r.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:E,params:T,prerenderManifest:n,routerServerContext:o}=i;try{let t=e.method||"GET",a=(0,l.getTracer)(),i=a.getActiveScopeSpan(),p=_.instrumentationOnRequestError.bind(_),u=async i=>_.render(e,r,{query:{...E,...T},params:T,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:n.preview,propagateError:!1,dev:_.isDev,page:"/api/files/list",internalRevalidate:null==o?void 0:o.revalidate,onError:(...t)=>p(e,...t)}).finally(()=>{if(!i)return;i.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let E=e.get("next.route");if(E){let e=`${t} ${E}`;i.setAttributes({"next.route":E,"http.route":E,"next.span_name":e}),i.updateName(e)}else i.updateName(`${t} ${s}`)});i?await u(i):await a.withPropagatedContext(e.headers,()=>a.trace(d.BaseServerSpan.handleRequest,{spanName:`${t} ${s}`,kind:l.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},u))}catch(e){if(_.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,N,"default",0,u,"handler",()=>c],6582)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__eac9cfa7._.js.map