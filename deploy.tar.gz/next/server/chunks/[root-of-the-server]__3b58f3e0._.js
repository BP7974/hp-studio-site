module.exports=[406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},4747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},5372,(e,t,r)=>{t.exports=e.x("better-sqlite3",()=>require("better-sqlite3"))},2692,(e,t,r)=>{let a,i,s,n=e.r(4747),E=new(e.r(5372))(n.join(process.cwd(),"hpstudio.db"));E.pragma("journal_mode = WAL"),E.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),i=(a=E.prepare("PRAGMA table_info(users)").all()).find(e=>"email"===e.name),s=a.find(e=>"phone"===e.name),(i&&1===i.notnull||s&&1===s.notnull)&&E.transaction(()=>{E.exec("DROP TABLE IF EXISTS users__migration_backup"),E.exec(`
      CREATE TABLE users__migration_backup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `),E.exec(`
      INSERT INTO users__migration_backup (id, name, email, phone, password_hash, created_at)
      SELECT id, name, email, phone, password_hash, created_at FROM users;
    `),E.exec("DROP TABLE users;"),E.exec("ALTER TABLE users__migration_backup RENAME TO users;")})(),E.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),E.exec(`
  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),E.exec(`
  CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash
  ON password_resets(token_hash);
`),E.exec(`
  CREATE TABLE IF NOT EXISTS verification_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_type TEXT NOT NULL CHECK(target_type IN ('email', 'phone')),
    target_value TEXT NOT NULL,
    purpose TEXT NOT NULL DEFAULT 'register',
    code_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),E.exec(`
  CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup
  ON verification_codes(target_type, target_value, purpose, created_at DESC);
`),t.exports=E},8510,(e,t,r)=>{t.exports=e.x("bcryptjs",()=>require("bcryptjs"))},6187,(e,t,r)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},6890,(e,t,r)=>{t.exports=e.x("cookie",()=>require("cookie"))},3064,(e,t,r)=>{let a=e.r(8510),i=e.r(6187),s=e.r(6890),n=e.r(2692),E=process.env.JWT_SECRET||"CHANGE_ME_HP_STUDIO_SECRET",o="hpstudio_token",T=e=>({id:e.id,name:e.name,email:e.email,phone:e.phone,created_at:e.created_at});function u(e){if(!e)return null;try{let t=i.verify(e,E),r=n.prepare("SELECT * FROM users WHERE id = ?").get(t.id);return r?T(r):null}catch(e){return null}}function d(e){return e.headers.cookie&&s.parse(e.headers.cookie)[o]||null}t.exports={hashPassword:async function e(e){return a.hash(e,10)},verifyPassword:async function e(e,t){return a.compare(e,t)},signToken:function(e){return i.sign({id:e.id},E,{expiresIn:"7d"})},setAuthCookie:function(e,t){e.setHeader("Set-Cookie",s.serialize(o,t,{httpOnly:!0,secure:!0,sameSite:"lax",path:"/",maxAge:604800}))},clearAuthCookie:function(e){e.setHeader("Set-Cookie",s.serialize(o,"",{httpOnly:!0,secure:!0,sameSite:"lax",path:"/",maxAge:0}))},requireUser:function(e,t){let r=u(d(e));return r||(t.status(401).json({error:"Authentication required"}),null)},getUserFromToken:u,getTokenFromRequest:d,serializeUser:T}},893,(e,t,r)=>{let{requireUser:a}=e.r(3064);t.exports=function(e,t){if("GET"!==e.method)return t.setHeader("Allow",["GET"]),t.status(405).json({error:"Method Not Allowed"});let r=a(e,t);if(r)return t.status(200).json({user:r})}},5642,e=>{"use strict";var t=e.i(6747),r=e.i(9245),a=e.i(4898),i=e.i(2950),s=e.i(893),n=e.i(7031),E=e.i(1927),o=e.i(6432);let T=(0,i.hoist)(s,"default"),u=(0,i.hoist)(s,"config"),d=new a.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/auth/me",pathname:"/api/auth/me",bundlePath:"",filename:""},userland:s,distDir:".next",relativeProjectDir:""});async function l(e,r,a){d.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let i="/api/auth/me";i=i.replace(/\/index$/,"")||"/";let s=await d.prepare(e,r,{srcPage:i});if(!s){r.statusCode=400,r.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:T,params:u,prerenderManifest:l,routerServerContext:p}=s;try{let t=e.method||"GET",a=(0,n.getTracer)(),s=a.getActiveScopeSpan(),o=d.instrumentationOnRequestError.bind(d),c=async s=>d.render(e,r,{query:{...T,...u},params:u,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:l.preview,propagateError:!1,dev:d.isDev,page:"/api/auth/me",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>o(e,...t)}).finally(()=>{if(!s)return;s.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==E.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${t} ${n}`;s.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),s.updateName(e)}else s.updateName(`${t} ${i}`)});s?await c(s):await a.withPropagatedContext(e.headers,()=>a.trace(E.BaseServerSpan.handleRequest,{spanName:`${t} ${i}`,kind:n.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},c))}catch(e){if(d.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,u,"default",0,T,"handler",()=>l])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__3b58f3e0._.js.map