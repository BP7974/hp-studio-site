module.exports=[406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},4747,(e,t,r)=>{t.exports=e.x("path",()=>require("path"))},5372,(e,t,r)=>{t.exports=e.x("better-sqlite3",()=>require("better-sqlite3"))},2692,(e,t,r)=>{let a,i,s,n=e.r(4747),o=new(e.r(5372))(n.join(process.cwd(),"hpstudio.db"));o.pragma("journal_mode = WAL"),o.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),i=(a=o.prepare("PRAGMA table_info(users)").all()).find(e=>"email"===e.name),s=a.find(e=>"phone"===e.name),(i&&1===i.notnull||s&&1===s.notnull)&&o.transaction(()=>{o.exec("DROP TABLE IF EXISTS users__migration_backup"),o.exec(`
      CREATE TABLE users__migration_backup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `),o.exec(`
      INSERT INTO users__migration_backup (id, name, email, phone, password_hash, created_at)
      SELECT id, name, email, phone, password_hash, created_at FROM users;
    `),o.exec("DROP TABLE users;"),o.exec("ALTER TABLE users__migration_backup RENAME TO users;")})(),o.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),o.exec(`
  CREATE TABLE IF NOT EXISTS password_resets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`),o.exec(`
  CREATE INDEX IF NOT EXISTS idx_password_resets_token_hash
  ON password_resets(token_hash);
`),o.exec(`
  CREATE TABLE IF NOT EXISTS verification_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_type TEXT NOT NULL CHECK(target_type IN ('email', 'phone')),
    target_value TEXT NOT NULL,
    purpose TEXT NOT NULL DEFAULT 'register',
    code_hash TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`),o.exec(`
  CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup
  ON verification_codes(target_type, target_value, purpose, created_at DESC);
`),t.exports=o},8510,(e,t,r)=>{t.exports=e.x("bcryptjs",()=>require("bcryptjs"))},6187,(e,t,r)=>{t.exports=e.x("jsonwebtoken",()=>require("jsonwebtoken"))},6890,(e,t,r)=>{t.exports=e.x("cookie",()=>require("cookie"))},3064,(e,t,r)=>{let a=e.r(8510),i=e.r(6187),s=e.r(6890),n=e.r(2692),o=process.env.JWT_SECRET||"CHANGE_ME_HP_STUDIO_SECRET",E="hpstudio_token",T=e=>({id:e.id,name:e.name,email:e.email,phone:e.phone,created_at:e.created_at});function l(e){if(!e)return null;try{let t=i.verify(e,o),r=n.prepare("SELECT * FROM users WHERE id = ?").get(t.id);return r?T(r):null}catch(e){return null}}function d(e){return e.headers.cookie&&s.parse(e.headers.cookie)[E]||null}t.exports={hashPassword:async function e(e){return a.hash(e,10)},verifyPassword:async function e(e,t){return a.compare(e,t)},signToken:function(e){return i.sign({id:e.id},o,{expiresIn:"7d"})},setAuthCookie:function(e,t){e.setHeader("Set-Cookie",s.serialize(E,t,{httpOnly:!0,secure:!0,sameSite:"lax",path:"/",maxAge:604800}))},clearAuthCookie:function(e){e.setHeader("Set-Cookie",s.serialize(E,"",{httpOnly:!0,secure:!0,sameSite:"lax",path:"/",maxAge:0}))},requireUser:function(e,t){let r=l(d(e));return r||(t.status(401).json({error:"Authentication required"}),null)},getUserFromToken:l,getTokenFromRequest:d,serializeUser:T}},7130,(e,t,r)=>{let a=e.r(2692),{requireUser:i}=e.r(3064);t.exports=function(e,t){if("GET"!==e.method)return t.setHeader("Allow",["GET"]),t.status(405).json({error:"Method Not Allowed"});let r=i(e,t);if(r)try{let e=a.prepare(`
      SELECT id, title, description, original_name, created_at
      FROM files
      WHERE user_id = ?
      ORDER BY created_at DESC
      LIMIT 100
    `).all(r.id).map(e=>({...e,downloadUrl:`/api/files/download/${e.id}`}));return t.status(200).json({files:e})}catch(e){return console.error("My files error",e),t.status(500).json({error:"Unable to load files"})}}},6553,e=>{"use strict";var t=e.i(6747),r=e.i(9245),a=e.i(4898),i=e.i(2950),s=e.i(7130),n=e.i(7031),o=e.i(1927),E=e.i(6432);let T=(0,i.hoist)(s,"default"),l=(0,i.hoist)(s,"config"),d=new a.PagesAPIRouteModule({definition:{kind:r.RouteKind.PAGES_API,page:"/api/files/mine",pathname:"/api/files/mine",bundlePath:"",filename:""},userland:s,distDir:".next",relativeProjectDir:""});async function u(e,r,a){d.isDev&&(0,E.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let i="/api/files/mine";i=i.replace(/\/index$/,"")||"/";let s=await d.prepare(e,r,{srcPage:i});if(!s){r.statusCode=400,r.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve());return}let{query:T,params:l,prerenderManifest:u,routerServerContext:p}=s;try{let t=e.method||"GET",a=(0,n.getTracer)(),s=a.getActiveScopeSpan(),E=d.instrumentationOnRequestError.bind(d),c=async s=>d.render(e,r,{query:{...T,...l},params:l,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:u.preview,propagateError:!1,dev:d.isDev,page:"/api/files/mine",internalRevalidate:null==p?void 0:p.revalidate,onError:(...t)=>E(e,...t)}).finally(()=>{if(!s)return;s.setAttributes({"http.status_code":r.statusCode,"next.rsc":!1});let e=a.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==o.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let n=e.get("next.route");if(n){let e=`${t} ${n}`;s.setAttributes({"next.route":n,"http.route":n,"next.span_name":e}),s.updateName(e)}else s.updateName(`${t} ${i}`)});s?await c(s):await a.withPropagatedContext(e.headers,()=>a.trace(o.BaseServerSpan.handleRequest,{spanName:`${t} ${i}`,kind:n.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},c))}catch(e){if(d.isDev)throw e;(0,t.sendError)(r,500,"Internal Server Error")}finally{null==a.waitUntil||a.waitUntil.call(a,Promise.resolve())}}e.s(["config",0,l,"default",0,T,"handler",()=>u])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__28c36ba2._.js.map