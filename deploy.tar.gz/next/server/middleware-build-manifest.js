globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/d01f5806e49cd2f6.js",
      "static/chunks/e4a7808872c6aaf7.js",
      "static/chunks/5205ada799cb7f0e.js",
      "static/chunks/turbopack-c480d74e8b9b43d9.js"
    ],
    "/_app": [
      "static/chunks/7c9581b7381a01b0.js",
      "static/chunks/e4a7808872c6aaf7.js",
      "static/chunks/5205ada799cb7f0e.js",
      "static/chunks/a2e7adcb50ed826e.css",
      "static/chunks/turbopack-fd898b96f3f3aa06.js"
    ],
    "/_error": [
      "static/chunks/79e2095ba55d04e6.js",
      "static/chunks/e4a7808872c6aaf7.js",
      "static/chunks/5205ada799cb7f0e.js",
      "static/chunks/turbopack-3ed15e47143c4c9b.js"
    ],
    "/auth": [
      "static/chunks/30360fd883d1e747.js",
      "static/chunks/e4a7808872c6aaf7.js",
      "static/chunks/5205ada799cb7f0e.js",
      "static/chunks/turbopack-32fdef0eaa69ee2a.js"
    ],
    "/dashboard": [
      "static/chunks/0509855952e7e80c.js",
      "static/chunks/e4a7808872c6aaf7.js",
      "static/chunks/5205ada799cb7f0e.js",
      "static/chunks/turbopack-90da3b351bd40814.js"
    ],
    "/explore": [
      "static/chunks/b3dcb677a8513e8d.js",
      "static/chunks/e4a7808872c6aaf7.js",
      "static/chunks/5205ada799cb7f0e.js",
      "static/chunks/turbopack-243aec3e0212b98c.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];