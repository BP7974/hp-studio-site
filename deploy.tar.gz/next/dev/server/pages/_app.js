var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/node_modules_c584bd3f._.js")
R.c("server/chunks/ssr/[root-of-the-server]__ec516c31._.js")
R.m("[project]/pages/_app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/pages/_app.js [ssr] (ecmascript)").exports
