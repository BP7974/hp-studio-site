var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/files/mine.js")
R.c("server/chunks/node_modules_next_dist_a5f72ae2._.js")
R.c("server/chunks/[root-of-the-server]__31621254._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/files/mine.js [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/pages/api/files/mine.js [api] (ecmascript)\" } [api] (ecmascript)").exports
