module.exports = [
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/better-sqlite3 [external] (better-sqlite3, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("better-sqlite3", () => require("better-sqlite3"));

module.exports = mod;
}),
"[project]/lib/db.js [api] (ecmascript)", ((__turbopack_context__, module, exports) => {

const path = __turbopack_context__.r("[externals]/path [external] (path, cjs)");
const Database = __turbopack_context__.r("[externals]/better-sqlite3 [external] (better-sqlite3, cjs)");
const dbFile = path.join(process.cwd(), 'hpstudio.db');
const db = new Database(dbFile);
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);
db.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);
module.exports = db;
}),
"[externals]/bcryptjs [external] (bcryptjs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("bcryptjs", () => require("bcryptjs"));

module.exports = mod;
}),
"[externals]/jsonwebtoken [external] (jsonwebtoken, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("jsonwebtoken", () => require("jsonwebtoken"));

module.exports = mod;
}),
"[externals]/cookie [external] (cookie, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("cookie", () => require("cookie"));

module.exports = mod;
}),
"[project]/lib/auth.js [api] (ecmascript)", ((__turbopack_context__, module, exports) => {

const bcrypt = __turbopack_context__.r("[externals]/bcryptjs [external] (bcryptjs, cjs)");
const jwt = __turbopack_context__.r("[externals]/jsonwebtoken [external] (jsonwebtoken, cjs)");
const cookie = __turbopack_context__.r("[externals]/cookie [external] (cookie, cjs)");
const db = __turbopack_context__.r("[project]/lib/db.js [api] (ecmascript)");
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_ME_HP_STUDIO_SECRET';
const TOKEN_NAME = 'hpstudio_token';
const serializeUser = (user)=>({
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        created_at: user.created_at
    });
async function hashPassword(password) {
    return bcrypt.hash(password, 10);
}
async function verifyPassword(password, hash) {
    return bcrypt.compare(password, hash);
}
function signToken(user) {
    return jwt.sign({
        id: user.id
    }, JWT_SECRET, {
        expiresIn: '7d'
    });
}
function setAuthCookie(res, token) {
    res.setHeader('Set-Cookie', cookie.serialize(TOKEN_NAME, token, {
        httpOnly: true,
        secure: ("TURBOPACK compile-time value", "development") === 'production',
        sameSite: 'lax',
        path: '/',
        maxAge: 7 * 24 * 60 * 60
    }));
}
function clearAuthCookie(res) {
    res.setHeader('Set-Cookie', cookie.serialize(TOKEN_NAME, '', {
        httpOnly: true,
        secure: ("TURBOPACK compile-time value", "development") === 'production',
        sameSite: 'lax',
        path: '/',
        maxAge: 0
    }));
}
function getUserFromToken(token) {
    if (!token) return null;
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const stmt = db.prepare('SELECT * FROM users WHERE id = ?');
        const user = stmt.get(decoded.id);
        return user ? serializeUser(user) : null;
    } catch (err) {
        return null;
    }
}
function getTokenFromRequest(req) {
    if (!req.headers.cookie) return null;
    const cookies = cookie.parse(req.headers.cookie);
    return cookies[TOKEN_NAME] || null;
}
function requireUser(req, res) {
    const token = getTokenFromRequest(req);
    const user = getUserFromToken(token);
    if (!user) {
        res.status(401).json({
            error: 'Authentication required'
        });
        return null;
    }
    return user;
}
module.exports = {
    hashPassword,
    verifyPassword,
    signToken,
    setAuthCookie,
    clearAuthCookie,
    requireUser,
    getUserFromToken,
    getTokenFromRequest,
    serializeUser
};
}),
"[project]/pages/api/files/mine.js [api] (ecmascript)", ((__turbopack_context__, module, exports) => {

const db = __turbopack_context__.r("[project]/lib/db.js [api] (ecmascript)");
const { requireUser } = __turbopack_context__.r("[project]/lib/auth.js [api] (ecmascript)");
module.exports = function handler(req, res) {
    if (req.method !== 'GET') {
        res.setHeader('Allow', [
            'GET'
        ]);
        return res.status(405).json({
            error: 'Method Not Allowed'
        });
    }
    const user = requireUser(req, res);
    if (!user) return;
    try {
        const stmt = db.prepare(`
      SELECT id, title, description, original_name, created_at
      FROM files
      WHERE user_id = ?
      ORDER BY created_at DESC
      LIMIT 100
    `);
        const files = stmt.all(user.id).map((row)=>({
                ...row,
                downloadUrl: `/api/files/download/${row.id}`
            }));
        return res.status(200).json({
            files
        });
    } catch (error) {
        console.error('My files error', error);
        return res.status(500).json({
            error: 'Unable to load files'
        });
    }
};
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__31621254._.js.map