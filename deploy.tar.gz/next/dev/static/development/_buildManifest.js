self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/api/auth/forgot",
    "/api/auth/login",
    "/api/auth/logout",
    "/api/auth/me",
    "/api/auth/register",
    "/api/auth/reset",
    "/api/auth/send-email-code",
    "/api/auth/send-phone-code",
    "/api/auth/send-reset-email-code",
    "/api/auth/send-reset-phone-code",
    "/api/files/download/[id]",
    "/api/files/list",
    "/api/files/mine",
    "/api/files/upload",
    "/auth",
    "/dashboard",
    "/explore"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()