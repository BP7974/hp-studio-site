__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_cc397485._.js",
  "static/chunks/node_modules_next_dist_client_3ede7da4._.js",
  "static/chunks/node_modules_next_dist_6024eba3._.js",
  "static/chunks/node_modules_next_54714aca._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_f1be3ba2._.js",
  "static/chunks/[root-of-the-server]__3e788f3d._.js",
  "static/chunks/pages_index_2da965e7._.js",
  "static/chunks/turbopack-pages_index_5f3c38cd._.js"
])
