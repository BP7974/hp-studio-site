__turbopack_load_page_chunks__("/dashboard", [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_2202bc1a._.js",
  "static/chunks/node_modules_next_dist_client_3ede7da4._.js",
  "static/chunks/node_modules_next_dist_6024eba3._.js",
  "static/chunks/node_modules_next_b8cbaf14._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_f1be3ba2._.js",
  "static/chunks/[root-of-the-server]__6b9c43a9._.js",
  "static/chunks/pages_dashboard_2da965e7._.js",
  "static/chunks/turbopack-pages_dashboard_5d0cd46e._.js"
])
